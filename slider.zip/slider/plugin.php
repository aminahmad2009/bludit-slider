<?php 

/**
* 
*/
class slider extends Plugin
{
	
	public function init()
	{
		// JSON predefined data
		$db = json_encode(array(
		));
		// var_dump(json_decode($db));
		// Fields and default values for the database of this plugin
		$this->dbFields = array(
			'label'=>'Slider',
			'interval' => '3',
			'controls'=>true,
			'db' => $db
		);

		// $this->db['label'] = Sanitize::html($_POST['label']);
		// $this->db['jsondb'] = Sanitize::html(json_encode($links));

		// Disable default Save and Cancel button
		$this->formButtons = false;
	}
	public function post()
	{
		global $site;
		// var_dump($_POST);
		$db = $this->db['db'];
		$db = Sanitize::htmlDecode($db);
		// Convert JSON to Array
		$obj = json_decode($db, true);


		if(isset($_POST['addLink'])){
			$id = sizeof($obj)+1;
			if($_POST['image']!==''){
				$obj[$id] = $site->url().'bl-plugins/slider/source/'.addslashes($_POST['image'])."{{|}}".addslashes($_POST['title'])."{{|}}".addslashes($_POST['text'])."{{|}}".addslashes($_POST['link']);
			}
			$this->db['interval'] = $_POST['duration'];
			$this->db['controls'] = $_POST['controls'];
		}


		if(isset($_POST['deleteImage'])){
			// var_dump($_POST);
			$key = $_POST['deleteImage'];
			unset($obj[$key]);
		}

		$this->db['db'] = Sanitize::html(json_encode($obj));
		// Save the database
		return $this->save();
	}
	public function form()
	{
		global $L;
		global $site;
		// var_dump($site->url());
		$html  = '<div class="alert alert-primary" role="alert">';
		$html .= '<a href="http://techmicrosol.tech">'.$this->description()."</a>";
		$html .= '</div>';
		$db = $this->getValue('db', $unsanitized=false);
		$control = $this->getValue('controls'); 
		if($control=='TRUE') $yes='selected'; else $no='selected';
		$links = json_decode($db, true);
		////////////////////////////////// Add new image //////////////////////
			$html .= '<div class="row"><div class="col-md-12"><h4 class="mt-3">'.$L->get('Add Slide').'</h4>';
			$html .= '<div>';
			$html .= '<input name="image" type="hidden" class="form-control " value="" placeholder="http://" id="input" onchange="loadImage()" >
			<a class="btn btn-primary my-2 iframe-btn" href="'.$site->url().'bl-plugins/slider/filemanager/dialog.php?type=1&field_id=input&relative_url=1&multiple=0">'.$L->get('Load File').'</a> <img class="img" width="300" src="" id="image" style="display:hidden">';
			$html .= '<input type="text" class="form-control my-2" name="title" placeholder="Title">';
			$html .= '<textarea class="form-control my-2" placeholder="Add text here..." name="text"></textarea>';
			$html .= '<input type="text" class="form-control my-2" name="link" placeholder="Link to page...">';
			$html .= '<span class="tip">'.$L->get('If no link given, button will not be displayed.').'</span>';
			$html .= '</div>';
			$html .= '<div>';
			$html .= '</div></div>';
			// $html .= '<div class="col-md-4 mt-3"><h4>Settings</h4>
			// 			<p>These control effects all slides</p>
			// 			<label>Duration (seconds)</label>
			// 			<input type="number" min="1" max="10" step="0.5" class="form-control" name="duration" value="'.$this->getValue('interval').'">
			// 			<label>Slider Controls</label>
			// 			<select class="form-control" name="controls">
			// 				<option value="TRUE" '.$yes.'>YES</option>
			// 				<option value="FALSE" '.$no.'>NO</option>
			// 			</select>
			// 		</div>';
			$html .= '<script>
						function loadImage(){
							var a =$("#input").val()
							$("#image").attr("src", "'.$site->url().'bl-plugins/slider/source/"+a).show();
						}
					</script>

					<script>
							$(\'.iframe-btn\').fancybox({	
							\'width\'		: 900,
							\'height\'	: 200,
							\'type\'		: \'iframe\',
						        \'autoScale\'    	: false
						    });
					</script>';
		////////////////////////////////////////////////////////////////////////
		$html .= '</div>
					<div class="text-right">';
		$html .= '<button name="addLink" class="btn btn-primary col-md-6 my-2" type="submit">'.$L->get('Save').'</button>';
		$html .= '</div>';

		// var_dump($links);
		// $html .= '<h3>Added Images</h3>';
		$html .='<table class="table">
			<head>
				<tr>
					<th> Image</th>
					<th> Title</th>
					<th> Link</th>
					<th> Delete</th>
				</tr>
			</head>
			<tbody>';
		foreach($links as $k => $v) {
			// var_dump($v);
			$a = explode("{{|}}", $v);
			$html .= '<tr>

						<td>
							<a data-fancybox="gallery" href="'.$a[0].'"><img class="img img-responsive" width="200" src="'.$a[0].'"/> </a>
						</td>
						<td>
							<p>'.$a[1].'</p>
						</td>
						<td>
							<a href="'.$a[3].'">'.$a[3].'</p>
						</td>
						<td>
							<button class="btn btn-danger" name="deleteImage" value="'.$k.'">Delete</button>
						</td>
					</tr>';
			echo $a->img;
		}
			$html .="<tbody></table>";

		return $html;
	}

	public function adminHead()
	{
		$html = '<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.6/jquery.fancybox.min.css">
		<script src="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.6/jquery.fancybox.min.js"></script>
		';
		return $html;
	}

	public function adminSidebar()
	{

		$html = '<li class="nav-item"><a class="nav-link" href="'.HTML_PATH_ADMIN_ROOT.'configure-plugin/slider">Slider</a></li>';
		return $html;
	}

	public function siteBodyBegin()
	{
		global $L;
		global $site;
		$db = $this->getValue('db', $unsanitized=false);
		$links = json_decode($db, true);
$html .='<div class="section_slider_aro">
    <div id="demo">
        <div id="owl-demo13" class="owl-carousel">';
        $data = array();
foreach($links as $k => $v) {
			$a = explode("{{|}}", $v);
   $html .='<div class="item">
                <div class="container_full">
                    <div class="caption">

                        <div class="col-md-5 padd_0 banner_red_left">
                            <div class="col-md-2"></div>

                            <div class="col-md-9">
                                <h1 class="fadeInDown-1 light-color">'.$a[1].'</h1>

                                <p>'.$a[2].'</p>';

                            if($v[3]){
                            	$html .='<a href="'.$a[3].'" class="banner_red_more">Read More </a>';}

                            $html .='</div>
                        </div>

                        <div class="col-md-7 padd_0 banner_right_img">
                            <img src="<?php echo $site->url()?>bl-content/uploads/images/1.jpg" alt="">
                        </div>

                    </div>
                </div>
            </div>';
}

$html .='
        </div>
    </div>
</div>';
			
// var_dump($site);
		return $html;
	}
}